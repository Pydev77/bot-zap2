const MultiDownload = () => {};

module.exports = { MultiDownload };