const fs = require('fs');
const axios = require('axios');
const crypto = require('crypto');

// Utility functions
const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const getExtension = (filename) => {
  return filename.split('.').pop();
};

const generateMessageID = () => {
  return crypto.randomBytes(16).toString('hex').toUpperCase();
};

const getMembros = (participants) => {
  return participants.map(user => user.id);
};

const getGroupAdmins = (participants) => {
  return participants.filter(user => user.admin).map(user => user.id);
};

const getRandom = (array) => {
  return array[Math.floor(Math.random() * array.length)];
};

const banner = () => "Takira Bot";
const banner2 = () => "Takira Bot v2";
const banner3 = () => "Takira Bot v3";

const temporizador = () => Date.now();

const chyt = [];
const nit = [];
const getpc = [];
const supre = [];

const getBuffer = async (url) => {
  try {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
};

const fetchJson = async (url) => {
  try {
    const response = await axios.get(url);
    return response.data;
  } catch (error) {
    throw error;
  }
};

const fetchText = async (url) => {
  try {
    const response = await axios.get(url);
    return response.data;
  } catch (error) {
    throw error;
  }
};

const createExif = () => ({});
const getBase64 = (buffer) => buffer.toString('base64');
const convertSticker = () => {};
const upload = () => {};
const recognize = () => {};

// Filter functions
const isFiltered = () => false;
const addFilter = () => {};

module.exports = {
  wait, getExtension, generateMessageID, getMembros, getGroupAdmins, getRandom,
  banner, banner2, banner3, temporizador, chyt, getBuffer, fetchJson, fetchText,
  createExif, getBase64, convertSticker, upload, nit, getpc, supre, recognize,
  isFiltered, addFilter
};