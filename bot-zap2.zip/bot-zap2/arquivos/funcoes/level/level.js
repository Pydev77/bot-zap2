const level2 = [];

module.exports = { level2 };