const psycatgames = [];

module.exports = { psycatgames };