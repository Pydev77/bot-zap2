const infoClima = () => {};

module.exports = { infoClima };