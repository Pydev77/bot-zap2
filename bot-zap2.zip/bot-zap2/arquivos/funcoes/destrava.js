const destrava = [];
const destrava2 = [];

module.exports = { destrava, destrava2 };