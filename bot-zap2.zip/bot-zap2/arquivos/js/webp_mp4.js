// Webp to MP4 conversion placeholder
module.exports = {
  toMp4: () => {},
  toWebp: () => {}
};