const palavrasANA = [];
const quizanimais = [];
const enigmaArchive = [];
const garticArchives = [];
const whatMusicAr = [];

module.exports = { palavrasANA, quizanimais, enigmaArchive, garticArchives, whatMusicAr };