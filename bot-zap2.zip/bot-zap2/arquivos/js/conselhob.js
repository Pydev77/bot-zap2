const conselhob = [];

module.exports = { conselhob };