const fatos = [];

module.exports = { fatos };