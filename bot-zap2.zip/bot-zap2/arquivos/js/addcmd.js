const addComandosId = () => {};
const deleteComandos = () => {};
const getComandoBlock = () => {};
const getComandos = () => {};
const addComandos = () => {};

module.exports = { addComandosId, deleteComandos, getComandoBlock, getComandos, addComandos };