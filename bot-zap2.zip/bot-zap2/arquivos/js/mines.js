const getMinesPositions = () => {};
const MinesHelp = () => {};

module.exports = { getMinesPositions, MinesHelp };