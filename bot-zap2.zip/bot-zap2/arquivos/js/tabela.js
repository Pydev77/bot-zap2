const tabela = [];

module.exports = { tabela };