const palavrasc = [];

module.exports = { palavrasc };