const randomCantadas = [];

module.exports = { randomCantadas };