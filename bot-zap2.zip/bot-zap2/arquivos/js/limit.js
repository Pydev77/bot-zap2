const addLimit = () => {};
const getLimit = () => {};

module.exports = { addLimit, getLimit };