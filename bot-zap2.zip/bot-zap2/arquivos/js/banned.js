const addBanned = () => {};
const unBanned = () => {};
const BannedExpired = () => {};
const cekBannedUser = () => {};

module.exports = { addBanned, unBanned, BannedExpired, cekBannedUser };