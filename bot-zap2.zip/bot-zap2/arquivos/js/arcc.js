const arcloud = () => {};

module.exports = { arcloud };