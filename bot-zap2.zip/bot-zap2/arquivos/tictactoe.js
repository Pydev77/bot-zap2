const validmove = () => {};
const setGame = () => {};

module.exports = { validmove, setGame };