const menu = "Takira Bot Menu";
const anotacao = [];
const menudono = "Owner Menu";
const adms = [];
const menulogos = "Logo Menu";
const efeitos = [];
const menuprem = "Premium Menu";
const brincadeiras = [];
const infodono = "Owner Info";
const alteradores = [];
const ftmenu = "Photo Menu";

module.exports = { menu, anotacao, menudono, adms, menulogos, efeitos, menuprem, brincadeiras, infodono, alteradores, ftmenu };