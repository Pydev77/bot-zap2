const sendVideoAsSticker2 = () => {};
const sendImageAsSticker2 = () => {};

module.exports = { sendVideoAsSticker2, sendImageAsSticker2 };