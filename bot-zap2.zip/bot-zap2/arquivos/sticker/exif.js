const writeExifImg = () => {};

module.exports = { writeExifImg };