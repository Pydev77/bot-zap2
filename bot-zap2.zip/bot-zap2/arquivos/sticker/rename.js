const sendVideoAsSticker = () => {};
const sendImageAsSticker = () => {};

module.exports = { sendVideoAsSticker, sendImageAsSticker };