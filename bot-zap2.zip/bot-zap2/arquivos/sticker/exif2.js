const writeExif2 = () => {};

module.exports = { writeExif2 };