const mensagens = [
  "⏱️ Aguarde um momento...",
  "🔄 Processando sua solicitação...",
  "⌛ Carregando, por favor aguarde...",
  "🔍 Buscando informações...",
  "📊 Analisando dados..."
];

const enviar = {
  wait: "⏱️ Aguarde um momento...",
  error: "❌ Ocorreu um erro!",
  success: "✅ Comando executado com sucesso!"
};

const sortear = (array) => {
  return array[Math.floor(Math.random() * array.length)];
};

module.exports = { mensagens, enviar, sortear };